# Excel Indent GUI

import sys
import os
from PyQt6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QPushButton, 
                             QLineEdit, QFileDialog, QLabel, QTextEdit, QHBoxLayout)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon
from Excel_Indent_Functions import indent_function, calculate_indents_and_save_new_excel

class ExcelProcessorGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Excel Indentation Generator")
        self.setGeometry(100, 100, 800, 100) # Initial window size

        # Set the icon
        script_dir = os.path.dirname(os.path.abspath(__file__))
        icon_path = os.path.join(script_dir, 'jama_logo_icon.png') 
        self.setWindowIcon(QIcon(icon_path)) 

        self.file_path = ""
        self.heading_column_name = ""

        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout()
        
        # File Selection Section
        file_selection_layout = QHBoxLayout()
        self.select_file_button = QPushButton("Select .xlsx File")
        self.select_file_button.clicked.connect(self.select_excel_file)
        file_selection_layout.addWidget(self.select_file_button)
        
        self.file_path_label = QLabel("No file selected")
        file_selection_layout.addWidget(self.file_path_label)
        main_layout.addLayout(file_selection_layout)

        # Heading Column Input Section
        heading_layout = QHBoxLayout()
        heading_label = QLabel("Heading Column Name:")
        heading_layout.addWidget(heading_label)
        self.heading_column_input = QLineEdit()
        self.heading_column_input.setPlaceholderText("e.g., 'Product Name'")
        self.heading_column_input.textChanged.connect(self.update_heading_column_name)
        heading_layout.addWidget(self.heading_column_input)
        main_layout.addLayout(heading_layout)

        # Run Button
        self.run_button = QPushButton("Run Processing")
        self.run_button.clicked.connect(self.run_processing)
        self.run_button.setEnabled(False) # Initially disabled
        main_layout.addWidget(self.run_button)

        # Output Console (initially hidden)
        self.output_console = QTextEdit()
        self.output_console.setReadOnly(True)
        self.output_console.setVisible(False) # Hide initially
        main_layout.addWidget(self.output_console)

        self.setLayout(main_layout)
        
        # Adjust window size based on content
        # self.adjustSize()

    def select_excel_file(self):
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(self, "Select Excel File", "", "Excel Files (*.xlsx)")
        if file_path:
            self.file_path = file_path
            self.file_path_label.setText(f"Selected: {self.file_path}")
            self.check_enable_run_button()

    def update_heading_column_name(self, text):
        self.heading_column_name = text
        self.check_enable_run_button()

    def check_enable_run_button(self):
        # Enable run button only if both file and heading are provided
        if self.file_path and self.heading_column_name:
            self.run_button.setEnabled(True)
        else:
            self.run_button.setEnabled(False)

    def run_processing(self):
        self.output_console.clear() # Clear previous output
        self.output_console.setVisible(True) # Show the console

        # Simulate calling two functions
        self.output_console.append("--- Starting Processing ---")
        
        # Call Function 1
        file, numbering_column, heading_column, output1 = calculate_indents_and_save_new_excel(self.file_path, self.heading_column_name)
        self.output_console.append(f"Function 1 Output:\n{output1}")

        # Call Function 2
        output2 = indent_function(file, numbering_column, heading_column)
        self.output_console.append(f"\nFunction 2 Output:\n{output2}")
        
        self.output_console.append("--- Processing Finished ---")
        
        # Adjust window size to show console
        self.adjustSize()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ExcelProcessorGUI()
    window.show()
    sys.exit(app.exec())

